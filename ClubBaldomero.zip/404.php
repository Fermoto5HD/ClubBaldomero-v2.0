<html>
	<header>
	<?php include ("header.php"); ?>
	</header>
	<body>
		<div id="estructura-cuerpo404">
			<center>
				<div id="error-titulo">Código 404 - Página no encontrada</div>
				<div id="error-descripcion">La dirección web no está bien escrita o la dimos de baja. <br>
				Quizás se trate de un error por parte nuestra. Si es así, reportalo.</div>
			</center>
		</div>
	</body>
	<footer>
		<?php include ("footer.php"); ?>
	</footer>
</html>