<div class="cover" id="club">
	<div class="cover-degrade">
		<div class="encuadre">
			<div class="cover-texto">
			Sobre el club
			<div class="cover-texto-parrafo">Próximamente habilitaremos esta sección.</div>
			</div>
		</div>
	</div>
</div>
<!--<center>
	<div class="club-bloque">
	</div>
</center>-->