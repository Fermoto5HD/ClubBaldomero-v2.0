		<div id="footer-BA"></div>
		<div class="footer-item" onclick="Home()">Home</div>
		<div class="footer-item" onclick="Club()">Sobre el club</div>
		<div class="footer-item" onclick="Aprendizaje()">Que podés aprender</div>
		<div class="footer-item" onclick="Proyectos()">Proyectos</div>
		<div class="footer-item" onclick="Galeria()">Galería de Fotos</div>
		<div class="footer-item" onclick="Contacto()">Contacto</div>
		<div>Realizado por el club de programación Baldomero</div>