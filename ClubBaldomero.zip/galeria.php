<div id="Cuerpo_Titulo">
	<div class="encuadre">
		<div class="titulo-alineacion">
			<div class="titulo">Galería de fotos</div>
		</div>
	</div>
</div>
<center>
	<div id="Galeria">
		<div class="encuadre">
			<div class="contenido-imagen" onclick="Galeria_AbrirVistaPrevia()" onclick="CargarImagenGaleria(Galeria01)"><div class="imagen-foto"></div><div class="imagen-texto">Foto 1</div></div>
			<div class="contenido-imagen" onclick="Galeria_AbrirVistaPrevia()"><div class="imagen-foto"></div><div class="imagen-texto">Foto 2</div></div>
			<div class="contenido-imagen" onclick="Galeria_AbrirVistaPrevia()"><div class="imagen-foto"></div><div class="imagen-texto">Foto 3</div></div>
			<div class="contenido-imagen" onclick="Galeria_AbrirVistaPrevia()"><div class="imagen-foto"></div><div class="imagen-texto">Foto 4</div></div>
		</div>
	</div>

	<div id="vista-previa" onclick="Galeria_CerrarVistaPrevia()"><div id="cuadro-blanco"><div id="cerrar-cuadro">Cerrar</div></div></div>
</center>