		<title>PTF - Biblioteca Baldomero Fernández Moreno</title>
		<meta property="og:description" content="Programá tu Futuro es el programa que incentiva a jóvenes y adultos a innovar y crear soluciones para el futuro de los argentinos.">
		<meta http-equiv="Content-Type" content="text/html" charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<link rel="shortcut icon" href="Imagenes/Favicon.ico">
		<!-- Estilos -->
		<link rel="stylesheet" type="text/css" href="css/estilos.css">
		<link rel="stylesheet" type="text/css" href="css/Contacto.css">
		<!-- Scripts -->
		<script type='text/javascript' src="js/jquery-2.1.0.min.js"></script>
		<script type='text/javascript' src="js/Motor_Ajax.js"></script>
		<script type="text/javascript" src="js/Acciones.js"></script>
		<script type="text/javascript" src="js/Contacto.js"></script>

		<div id="estructura-encabezado-navegacion">
			<div class="encuadre">
				<div id="encabezado-BAciudad" onclick="Home()" alt="Buenos Aires Ciudad"></div>
				<div class="encabezado-navegacion">
					<div class="navegacion-item" id="home" onclick="Home()">Home</div>
					<div class="navegacion-item" id="acerca-de" onclick="Club()">Sobre el club</div>
					<div class="navegacion-item" id="aprendizaje" onclick="Aprendizaje()">Que podés aprender</div>
					<div class="navegacion-item" id="proyectos" onclick="Proyectos()">Proyectos</div>
					<div class="navegacion-item" id="galeria" onclick="Galeria()">Galería de Fotos</div>
					<div class="navegacion-item" id="contacto" onclick="Contacto()">Contacto</div>
				</div>
			</div>
		</div>