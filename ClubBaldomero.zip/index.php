<html>
	<header>
		<?php 
			include ("header.php");
			//$pagina = (isset($_GET["pagina"]))?$_GET["pagina"]:"home";
			//include ($pagina.".php");
		?>
	</header>
	<body>
		<div id="Estructura_Cuerpo">
			<div id="cuerpo-contenido">
			<div id="Cuerpo_Titulo"><div class="encuadre"><div id="Titulo"><?php //echo $Titulo;?></div></div></div>
				<?php //echo $Cuerpo; ?>
			</div>
		</div>
	</body>
	<footer>
		<?php include ("footer.php"); ?>
	</footer>
</html>