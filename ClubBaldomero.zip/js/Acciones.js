function Home() {
    //setTimeout (location.href="index.php", 1);
    url = "home";
	CargarPaginaSeccion();
};
function Club() {
    //setTimeout (location.href="index.php?pagina=club", 1);
	url = "club";
	CargarPaginaSeccion();
   $(".cover").load("Imagenes/BA.png");  
};
function Aprendizaje() {
    //setTimeout (location.href="index.php?pagina=proyectos", 1);
    url = "aprendizaje";
	CargarPaginaSeccion();
};
function Proyectos() {
    //setTimeout (location.href="index.php?pagina=proyectos", 1);
    url = "proyectos";
	CargarPaginaSeccion();
};
function Galeria() {
    //setTimeout (location.href="index.php?pagina=galeria", 1);
    url = "galeria";
	CargarPaginaSeccion();
};
function Contacto() {
    //setTimeout (location.href="index.php?pagina=contacto", 1);
    url = "contacto";
	CargarPaginaSeccion();
};


function HaciaArriba() {
	$('html, body').animate({scrollTop:0}, 500);
}

function Galeria_AbrirVistaPrevia(){
	$("#vista-previa").fadeIn();
	//$("#vista-previa").show(); 
	$("body").css("overflow", "hidden");
}
function Galeria_CerrarVistaPrevia(){
	$("#vista-previa").fadeOut();
	//$("#vista-previa").hide(); 
	$("body").css("overflow", "inherit");
}