<div id="Cuerpo_Titulo">
	<div class="encuadre">
		<div class="titulo-alineacion">
			<div class="titulo">Te contamos nuestros proyectos</div>
		</div>
	</div>
</div>
<center>
	<div class="proyectospagina-bloque">
		<div class="encuadre">
			<h1>Estos son los proyectos que encabezamos</h1>
			<div class="proyecto-bloque">
				<div class="bloque-imagen"><img src="Imagenes/Proyectos_01.png" width="100%"></div>
				<div class="bloque-texto">
					<div class="texto-titulo">Página del club</div>
					<div class="texto-parrafo">El objetivo del proyecto fue crear, entre todo el grupo, cada parte del sitio web del club de programación. Aprendiendo distintos lenguajes, se fué logrando una evolución versión tras versión, hasta llegar a la versión actual.</div>
				</div>
			</div>
			<div class="proyecto-bloque">
				<div class="bloque-imagen"><img src="Imagenes/Proyectos_01.png" width="100%"></div>
				<div class="bloque-texto">
					<div class="texto-titulo">Bolsa de músicos</div>
					<div class="texto-parrafo">El objetivo del proyecto fue crear una bolsa laboral especial para músicos, donde los músicos puedan demostrar sus talentos y las bandas puedan encontrar los talentos disponibles en el portal.</div>
				</div>
			</div>
			<div class="proyecto-bloque">
				<div class="bloque-imagen"><img src="Imagenes/Proyectos_01.png" width="100%"></div>
				<div class="bloque-texto">
					<div class="texto-titulo">Proyecto 3</div>
					<div class="texto-parrafo">El objetivo del proyecto fue crear una bolsa laboral especial para músicos, donde los músicos puedan demostrar sus talentos y las bandas puedan encontrar los talentos disponibles en el portal.</div>
				</div>
			</div>
		</div>
	</div>
</center>